package com.superb.service;

import com.superb.entity.DataType;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Superb
 * @since 2021-04-19
 */
public interface DataTypeService extends IService<DataType> {

}
