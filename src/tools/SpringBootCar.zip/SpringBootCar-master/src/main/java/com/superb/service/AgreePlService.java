package com.superb.service;

import com.superb.entity.AgreePl;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Superb
 * @since 2021-03-30
 */
public interface AgreePlService extends IService<AgreePl> {

}
