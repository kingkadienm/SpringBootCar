package com.superb.mapper;

import com.superb.entity.Reputation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Superb
 * @since 2021-05-10
 */
public interface ReputationMapper extends BaseMapper<Reputation> {

}
