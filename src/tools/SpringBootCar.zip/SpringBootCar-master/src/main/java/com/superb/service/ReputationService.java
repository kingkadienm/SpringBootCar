package com.superb.service;

import com.superb.entity.Reputation;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Superb
 * @since 2021-05-10
 */
public interface ReputationService extends IService<Reputation> {

}
