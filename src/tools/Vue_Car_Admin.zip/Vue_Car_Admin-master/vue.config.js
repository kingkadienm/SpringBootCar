module.exports = {
    devServer: {
        port: 8082 // 端口号
    }
};