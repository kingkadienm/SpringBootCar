export default {
    msg: function (obj, data) {
        if (obj != null && data != null) {
            obj.$message({
                showClose: true,
                message: data.msg,
                type: data.code === 200 ? 'success' : 'info'
            });
        }
    },
    customMsg: function (obj, code, msg) {
        if (obj != null && code != null && msg != null) {
            obj.$message({
                showClose: true,
                message: msg,
                type: code === 200 ? 'success' : 'info'
            });
        }
    },
    successMsg: function (obj, msg) {
        if (obj != null && msg != null) {
            obj.$message({
                showClose: true,
                message: msg,
                type: 'success'
            });
        }
    },
    infoMsg: function (obj, msg) {
        if (obj != null && msg != null) {
            obj.$message({
                showClose: true,
                message: msg,
                type: 'info'
            });
        }
    }
}