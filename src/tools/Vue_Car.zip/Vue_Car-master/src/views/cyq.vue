<template>
  <div>
    <Header></Header>
    <div style="margin-top: 35px;">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>车友圈</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div>
    <div style="margin: 0 0 20px 1200px">
      <el-button type="primary" icon="el-icon-plus" round @click="to">发表</el-button>
    </div>
    <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
      <el-tab-pane label="原创" name="first">
        <div v-if="page.total !== 0">
        <div>
        <el-timeline>
          <el-timeline-item v-for='(record,index) in page.records' :key="index" placement="top">
            <el-card style="padding-left: 50px">
              <router-link :to="{name: 'ckyh',query: {userId: record.userId}}">
                <img style="width: 60px;height: 60px" v-if="record.user.photo" :src="record.user.photo">
                <el-avatar v-else :size="60" style="color: indianred"> {{record.user.userName}} </el-avatar>
              </router-link>
              <h2><router-link :to="{name: 'dtxq',query: {essayId: record.essayId}}">{{record.essayTitle}}</router-link></h2>
              <h4 style="color: red" v-if="record.essayLabel">
                <span style="margin-right: 20px" v-for="item in record.essayLabel">#{{item.labelText}}#</span>
              </h4>
              发表于 {{record.createTime}}
              <el-badge :value="record.forwardCount" class="item2" type="primary">
                <el-button size="small" @click="forward(record.essayId)">转发</el-button>
              </el-badge>
              <el-badge :value="record.agreeCount" class="item">
                <el-button size="small" @click="agree(record.essayId)">点赞</el-button>
              </el-badge>
              <el-badge :value="record.commentCount" class="item" type="warning">
                <el-button size="small" @click="comment(record.essayId)">评论</el-button>
              </el-badge>
            </el-card>
          </el-timeline-item>
        </el-timeline>
      </div>
        <div>
          <el-pagination
            background="true"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="page.current"
            :page-sizes="[5, 8, 10, 15]"
            :page-size="page.size"
            layout="total, sizes, prev, pager, next, jumper"
            :total="page.total">
          </el-pagination>
        </div>
        </div>
        <div style="margin: 200px 500px" v-else><h2 style="color: red">暂无数据</h2></div>
      </el-tab-pane>
      <el-tab-pane label="转发" name="second">
        <div v-if="pageForward.total !== 0">
        <div>
          <el-timeline>
            <el-timeline-item v-for='(record,index) in pageForward.records' :key="index" placement="top">
              <h3><router-link :to="{name: 'ckyh',query: {userId: record.userId}}">{{record.user.userName}}</router-link><i class="vip"><img src="../assets/icons/vip.png" alt="vip" /> </i></h3>
              <h2>{{record.forwardTitle}}</h2>
              <h5>转发于 {{record.createTime}}</h5>
              <el-card style="padding-left: 50px" v-if="record.essay">
                <router-link :to="{name: 'ckyh',query: {userId: record.essay.userId}}">
                  <img style="width: 60px;height: 60px" v-if="record.essay.user.photo" :src="record.essay.user.photo">
                  <el-avatar v-else :size="60" style="color: indianred"> {{record.essay.user.userName}} </el-avatar>
                </router-link>
                <h2><router-link :to="{name: 'dtxq',query: {essayId: record.essay.essayId}}">{{record.essay.essayTitle}}</router-link></h2>
                <h4 style="color: red" v-if="record.essay.essayLabel">
                  <span style="margin-right: 20px" v-for="item in record.essay.essayLabel">#{{item.labelText}}#</span>
                </h4>
                发表于 {{record.essay.createTime}}
                <el-badge :value="record.essay.forwardCount" class="item2" type="primary">
                  <el-button size="small" @click="forward(record.essay.essayId)">转发</el-button>
                </el-badge>
                <el-badge :value="record.essay.agreeCount" class="item">
                  <el-button size="small" @click="agree(record.essay.essayId)">点赞</el-button>
                </el-badge>
                <el-badge :value="record.essay.commentCount" class="item" type="warning">
                  <el-button size="small" @click="comment(record.essay.essayId)">评论</el-button>
                </el-badge>
              </el-card>
              <el-card v-else>原文已删除</el-card>
            </el-timeline-item>
          </el-timeline>
        </div>
        <div>
          <el-pagination
            background="true"
            @size-change="handleSizeChange2"
            @current-change="handleCurrentChange2"
            :current-page="pageForward.current"
            :page-sizes="[5, 8, 10, 15]"
            :page-size="pageForward.size"
            layout="total, sizes, prev, pager, next, jumper"
            :total="pageForward.total">
          </el-pagination>
        </div>
        </div>
        <div style="margin: 200px 500px" v-else><h2 style="color: red">暂无数据</h2></div>
      </el-tab-pane>
    </el-tabs>
    </div>
  </div>
</template>
<!--我的动态-->
<script>
import Header from '../components/header'
export default {
  name: 'cyq',
  components: { Header },
  // 页面刷新
  inject: ['reload'],
  data () {
    return {
      // 原创
      page: {
        records: [],
        current: 1,
        total: 20,
        size: 5
      },
      // 转发
      pageForward: {
        records: [],
        current: 1,
        total: 20,
        size: 5
      },
      activeName: 'first'
    }
  },
  methods: {
    handleSizeChange (val) {
      const that = this
      this.axios.get('/essay/list?size=' + val).then(function (rest) {
        that.page = rest.data.data
      }, function (error) {
        console.log(error)
      })
    },
    handleCurrentChange (val) {
      const that = this
      this.axios.get('/essay/list?size=' + that.page.size + '&current=' + val).then(function (rest) {
        that.page = rest.data.data
      }, function (error) {
        console.log(error)
      })
    },
    handleSizeChange2 (val) {
      const that = this
      this.axios.get('/forward/list?size=' + val).then(function (rest) {
        that.pageForward = rest.data.data
      }, function (error) {
        console.log(error)
      })
    },
    handleCurrentChange2 (val) {
      const that = this
      this.axios.get('/forward/list?size=' + that.pageForward.size + '&current=' + val).then(function (rest) {
        that.pageForward = rest.data.data
      }, function (error) {
        console.log(error)
      })
    },
    // 转发
    forward (essayId) {
      const user = this.$store.getters.GET_USER
      // 判断是否已登录
      if (!user) {
        this.util.infoMsg(this, '您还没登录...')
        this.$router.push('/login')
        return false
      }
      this.$prompt('说点什么吧...', '转发', {
        confirmButtonText: '转发',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        const that = this
        this.axios.post('/forward/add', { userId: user.userId, essayId: essayId, forwardTitle: value }).then(rest => {
          that.reload()
          that.util.msg(that, rest.data)
        })
      }).catch(() => {
        this.util.infoMsg(this, '取消转发')
      })
    },
    // 评论
    comment (essayId) {
      const user = this.$store.getters.GET_USER
      // 判断是否已登录
      if (!user) {
        this.util.infoMsg(this, '您还没登录...');
        this.$router.push('/login')
        return false
      }
      this.$prompt('说说你的看法...', '评论', {
        confirmButtonText: '评论',
        cancelButtonText: '取消',
        inputPattern: /[^]/,
        inputErrorMessage: '说点什么吧...'
      }).then(({ value }) => {
        const that = this
        this.axios.post('/comment/add', { userId: user.userId, essayId: essayId, commentText: value }).then(rest => {
          that.reload()
          that.util.msg(that, rest.data)
        })
      }).catch(() => {
        this.util.infoMsg(this, '取消评论');
      })
    },
    // 点赞
    agree (essayId) {
      const user = this.$store.getters.GET_USER
      // 判断是否已登录
      if (!user) {
        this.util.infoMsg(this, '您还没登录...');
        this.$router.push('/login')
        return false
      }
      const that = this
      this.axios.post('/agree/addDelete', { userId: user.userId, essayId: essayId }).then(rest => {
        that.reload()
        that.util.msg(that, rest.data);
      })
    },
    // 跳转发表动态
    to () {
      const user = this.$store.getters.GET_USER
      // 判断是否已登录
      if (!user) {
        this.util.infoMsg(this, '您还没登录...');
        this.$router.push('/login')
        return false
      }
      this.$router.push('/fbdt')
    },
    handleClick (tab, event) {
      console.log(tab, event)
    }
  },
  created () {
    const that = this
    this.axios.get('/essay/list').then(function (rest) {
      that.page = rest.data.data
    }, function (error) {
      console.log(error)
    })
    this.axios.get('/forward/list').then(function (rest) {
      that.pageForward = rest.data.data
    }, function (error) {
      console.log(error)
    })
  }
}
</script>

<style scoped>
  .item {
    margin-top: 10px;
    margin-right: 40px;
  }
  .item2 {
    margin-top: 10px;
    margin-right: 40px;
    margin-left: 500px;
  }
  .vip img{
    margin: 0 3px;
    width: 40px;
  }

  a {
    color: #000;
    text-decoration: none;
  }
  a:hover {
    color: #e65800;
  }
</style>
