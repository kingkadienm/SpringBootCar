#  基于SpringBoot+Vue的前后端分离开发汽车之家资讯论坛系统设计与实现

#### 介绍
此部分为前端Vue代码

#### 软件架构
略

#### 演示地址
http://101.43.254.35/

用户名：admin 密码：1

有效期至 2023/04/28


#### 安装教程

1.  导入项目
2.  构建Vue环境
3.  执行 npm install
4.  执行 npm run serve 启动

#### 使用说明

略

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request

#### 效果图
![输入图片说明](preview/%E9%A6%96%E9%A1%B5.png)
![输入图片说明](preview/%E9%80%89%E8%BD%A6.png)
![输入图片说明](preview/%E8%BD%A6%E6%8E%92%E8%A1%8C.png)
![输入图片说明](preview/%E8%A7%86%E9%A2%91%E6%92%AD%E6%94%BE.png)
![输入图片说明](preview/%E6%96%87%E7%AB%A0%E8%AF%A6%E6%83%85.png)
![输入图片说明](preview/%E6%96%87%E7%AB%A0%E5%8F%91%E5%B8%83.png)
![输入图片说明](preview/%E6%96%87%E7%AB%A0%E5%88%97%E8%A1%A8.png)
![输入图片说明](preview/%E5%90%8E%E5%8F%B0%E9%A6%96%E9%A1%B5%E7%BB%9F%E8%AE%A1.png)
![输入图片说明](preview/%E5%90%8E%E5%8F%B0%E6%B1%BD%E8%BD%A6%E7%AE%A1%E7%90%86.png)
![输入图片说明](preview/%E5%8A%A8%E6%80%81%E5%8F%91%E5%B8%83.png)
![输入图片说明](preview/%E5%8A%A8%E6%80%81%E5%88%97%E8%A1%A8.png)



#### 特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
